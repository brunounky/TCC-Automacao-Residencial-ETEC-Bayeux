package com.example.smartsocketteste87634257.Activities.Activities.Sensor;

import android.webkit.WebViewClient;

public class MyWebViewClient extends WebViewClient {


}
