package com.example.smartsocketteste87634257.Activities.Activities;

import android.app.Dialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Spinner;

import com.example.smartsocketteste87634257.R;

public class b_PopupAddRotina extends AppCompatActivity {

    Dialog myDialog4;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.janela_custom_popup_add_rotina);


        myDialog4 = new Dialog(this);




    }
}
